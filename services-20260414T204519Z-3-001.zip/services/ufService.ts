import { db } from '../db/database';
import { uf } from '../db/schema';
import { eq } from 'drizzle-orm';

export async function createUF(nome: string, sigla: string) {
  try {
    const result = db.insert(uf).values({ nome, sigla }).run();
    return { success: true, id: result.lastInsertRowid };
  } catch (error: any) {
    if (error.message.includes('UNIQUE constraint failed')) {
      return { success: false, error: 'UF com essa sigla já existe!' };
    }
    return { success: false, error: error.message };
  }
}

export function getAllUFs() {
  try {
    const result = db.select().from(uf).all();
    return { success: true, data: result };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

export function getUFById(id: number) {
  try {
    const result = db.select().from(uf).where(eq(uf.id, id)).get();
    return { success: true, data: result };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

export function getUFBySigla(sigla: string) {
  try {
    const result = db.select().from(uf).where(eq(uf.sigla, sigla)).get();
    return { success: true, data: result };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}
