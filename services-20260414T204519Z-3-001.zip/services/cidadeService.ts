import { db } from '../db/database';
import { cidade } from '../db/schema';
import { eq } from 'drizzle-orm';

export async function createCidade(nome: string, uf_id: number) {
  try {
    const result = db.insert(cidade).values({ nome, uf_id }).run();
    return { success: true, id: result.lastInsertRowid };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

export function getAllCidades() {
  try {
    const result = db.select().from(cidade).all();
    return { success: true, data: result };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

export function getCidadeById(id: number) {
  try {
    const result = db.select().from(cidade).where(eq(cidade.id, id)).get();
    return { success: true, data: result };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

export function getCidadesByUF(uf_id: number) {
  try {
    const result = db.select().from(cidade).where(eq(cidade.uf_id, uf_id)).all();
    return { success: true, data: result };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}
