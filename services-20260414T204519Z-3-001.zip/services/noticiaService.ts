import { db } from '../db/database';
import { noticia, cidade, uf } from '../db/schema';
import { eq, desc, asc } from 'drizzle-orm';

export async function createNoticia(titulo: string, texto: string, cidade_id: number) {
  try {
    const data_criacao = Math.floor(Date.now() / 1000);
    const result = db
      .insert(noticia)
      .values({ titulo, texto, cidade_id, data_criacao })
      .run();
    return { success: true, id: result.lastInsertRowid };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

export function getAllNoticias() {
  try {
    const result = db.select().from(noticia).all();
    return { success: true, data: result };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

export function getNoticiaById(id: number) {
  try {
    const result = db.select().from(noticia).where(eq(noticia.id, id)).get();
    return { success: true, data: result };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

export function getNoticiasByCidade(cidade_id: number) {
  try {
    const result = db
      .select()
      .from(noticia)
      .where(eq(noticia.cidade_id, cidade_id))
      .all();
    return { success: true, data: result };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

// Opção 1: Mais recentes primeiro
export function getNoticiasRecentes() {
  try {
    const result = db.select().from(noticia).orderBy(desc(noticia.data_criacao)).all();
    return { success: true, data: result };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

// Opção 2: Mais antigas primeiro
export function getNoticiasAntigas() {
  try {
    const result = db.select().from(noticia).orderBy(asc(noticia.data_criacao)).all();
    return { success: true, data: result };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

// Opção 3: Noticias de um estado específico
export function getNoticiasPorEstado(sigla_uf: string) {
  try {
    const result = db
      .select({
        noticia_id: noticia.id,
        titulo: noticia.titulo,
        texto: noticia.texto,
        data_criacao: noticia.data_criacao,
        cidade_nome: cidade.nome,
        uf_sigla: uf.sigla,
      })
      .from(noticia)
      .innerJoin(cidade, eq(noticia.cidade_id, cidade.id))
      .innerJoin(uf, eq(cidade.uf_id, uf.id))
      .where(eq(uf.sigla, sigla_uf))
      .all();
    return { success: true, data: result };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

// Opção 4: Noticias agrupadas por estado
export function getNoticiasAgrupadas() {
  try {
    const result = db
      .select({
        uf_sigla: uf.sigla,
        uf_nome: uf.nome,
        noticia_id: noticia.id,
        titulo: noticia.titulo,
        texto: noticia.texto,
        cidade_nome: cidade.nome,
        data_criacao: noticia.data_criacao,
      })
      .from(noticia)
      .innerJoin(cidade, eq(noticia.cidade_id, cidade.id))
      .innerJoin(uf, eq(cidade.uf_id, uf.id))
      .orderBy(uf.sigla, desc(noticia.data_criacao))
      .all();

    // Agrupar por UF
    const agrupadas: { [key: string]: any[] } = {};
    result.forEach((item) => {
      if (!agrupadas[item.uf_sigla]) {
        agrupadas[item.uf_sigla] = [];
      }
      agrupadas[item.uf_sigla].push(item);
    });

    return { success: true, data: agrupadas };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}
