import * as readline from 'readline';

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

export function question(prompt: string): Promise<string> {
  return new Promise((resolve) => {
    rl.question(prompt, (answer) => {
      resolve(answer.trim());
    });
  });
}

export function close() {
  rl.close();
}

export function print(message: string) {
  console.log(message);
}

export function printError(message: string) {
  console.error(`\n Erro: ${message}\n`);
}

export function printSuccess(message: string) {
  console.log(`\n ${message}\n`);
}

export function printInfo(message: string) {
  console.log(`\n  ${message}\n`);
}

export function printSeparator() {
  console.log('\n' + '='.repeat(60) + '\n');
}
