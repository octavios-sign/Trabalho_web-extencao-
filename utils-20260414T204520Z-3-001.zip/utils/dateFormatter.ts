export function formatarData(timestamp: number): string {
  const data = new Date(timestamp * 1000);
  return data.toLocaleString('pt-BR');
}

export function obterTimestampAtual(): number {
  return Math.floor(Date.now() / 1000);
}
