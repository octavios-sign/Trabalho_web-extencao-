import { sql } from 'drizzle-orm';
import { integer, sqliteTable, text, primaryKey } from 'drizzle-orm/sqlite-core';

// Tabela UF
export const uf = sqliteTable('uf', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  nome: text('nome').notNull(),
  sigla: text('sigla').notNull().unique(),
});

// Tabela Cidade
export const cidade = sqliteTable('cidade', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  nome: text('nome').notNull(),
  uf_id: integer('uf_id')
    .notNull()
    .references(() => uf.id),
});

// Tabela Noticia
export const noticia = sqliteTable('noticia', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  titulo: text('titulo').notNull(),
  texto: text('texto').notNull(),
  cidade_id: integer('cidade_id')
    .notNull()
    .references(() => cidade.id),
  data_criacao: integer('data_criacao')
    .notNull()
    .default(sql`(strftime('%s', 'now'))`),
});

export type UF = typeof uf.$inferSelect;
export type Cidade = typeof cidade.$inferSelect;
export type Noticia = typeof noticia.$inferSelect;
