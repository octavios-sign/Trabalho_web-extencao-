import Database from 'better-sqlite3';
import { drizzle } from 'drizzle-orm/better-sqlite3';
import * as schema from './schema';
import * as fs from 'fs';
import * as path from 'path';

const dbPath = path.join(process.cwd(), 'conecta-serv.db');

// Criar banco de dados se não existir
const sqlite = new Database(dbPath);

// Inicializar Drizzle ORM
export const db = drizzle(sqlite, { schema });

// Função para inicializar o banco de dados com as tabelas
export function initializeDatabase() {
  // Criar tabelas se não existirem
  sqlite.exec(`
    CREATE TABLE IF NOT EXISTS uf (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL,
      sigla TEXT NOT NULL UNIQUE
    );

    CREATE TABLE IF NOT EXISTS cidade (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL,
      uf_id INTEGER NOT NULL,
      FOREIGN KEY (uf_id) REFERENCES uf(id)
    );

    CREATE TABLE IF NOT EXISTS noticia (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      titulo TEXT NOT NULL,
      texto TEXT NOT NULL,
      cidade_id INTEGER NOT NULL,
      data_criacao INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
      FOREIGN KEY (cidade_id) REFERENCES cidade(id)
    );
  `);
}

export function closeDatabase() {
  sqlite.close();
}
